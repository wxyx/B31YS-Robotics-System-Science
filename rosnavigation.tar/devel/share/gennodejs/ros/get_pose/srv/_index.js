
"use strict";

let GetPose = require('./GetPose.js')

module.exports = {
  GetPose: GetPose,
};
