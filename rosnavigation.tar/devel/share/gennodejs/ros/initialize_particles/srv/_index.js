
"use strict";

let GlobalLocalization = require('./GlobalLocalization.js')

module.exports = {
  GlobalLocalization: GlobalLocalization,
};
