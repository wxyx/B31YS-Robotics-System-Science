#!/usr/bin/env python

import rospy
from make_plan.srv import MakePlan
from geometry_msgs.msg import PoseStamped

def make_plan_client(start_pose, goal_pose):
    rospy.wait_for_service('/move_base/make_plan')

    try:
        make_plan = rospy.ServiceProxy('/move_base/make_plan', MakePlan)

        start = PoseStamped()
        start.header.frame_id = 'map'
        start.pose.position.x = start_pose[0]
        start.pose.position.y = start_pose[1]
        start.pose.orientation.w = 1.0

        goal = PoseStamped()
        goal.header.frame_id = 'map'
        goal.pose.position.x = goal_pose[0]
        goal.pose.position.y = goal_pose[1]
        goal.pose.orientation.w = 1.0

        response = make_plan(start, goal, 0.1)  # Set the tolerance as needed
        return response.plan

    except rospy.ServiceException as e:
        print(f"Service call failed: {e}")

if __name__ == '__main__':
    rospy.init_node('make_plan_client')

    # Set your start and goal poses (replace these with your actual values)
    start_pose = (0.0, 0.0)
    goal_pose = (1.0, 1.0)

    plan = make_plan_client(start_pose, goal_pose)

    if plan:
        print("Received plan:")
        print(plan)
    else:
        print("Failed to get plan.")
