#!/usr/bin/env python

import rospy
from get_pose.srv import GetPose

def call_get_pose_service():
    rospy.wait_for_service('get_pose')
    try:
        get_pose = rospy.ServiceProxy('get_pose', GetPose)
        response = get_pose()
        rospy.loginfo("Robot pose: %s", response.pose)
    except rospy.ServiceException as e:
        rospy.logerr("Service call failed: %s", e)

if __name__ == "__main__":
    rospy.init_node('call_get_pose_service')
    call_get_pose_service()
