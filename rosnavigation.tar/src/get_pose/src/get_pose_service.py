#!/usr/bin/env python

# 导入自动生成的GetPose服务
import rospy
from get_pose.srv import GetPose, GetPoseResponse
from geometry_msgs.msg import PoseStamped

# 在handle_get_pose函数中使用PoseStamped类型
def handle_get_pose(req):
    # 创建PoseStamped消息类型的实例，表示机器人的位姿
    current_pose = PoseStamped()
    current_pose.header.stamp = rospy.Time.now()
    current_pose.header.frame_id = "map"
    current_pose.pose.position.x = -0.8705844290849024
    current_pose.pose.position.y = 2.5139421822477677
    current_pose.pose.position.z = 0.0
    current_pose.pose.orientation.x = 0.0
    current_pose.pose.orientation.y = 0.0
    current_pose.pose.orientation.z = 0.5812093598376356
    current_pose.pose.orientation.w = 0.8137540660648804

    rospy.loginfo("Returning current robot pose: %s", current_pose)

    return GetPoseResponse(current_pose)

# 在get_pose_server函数中调用新定义的服务
def get_pose_server():
    rospy.init_node('get_pose_server')
    service = rospy.Service('get_pose', GetPose, handle_get_pose)
    rospy.loginfo("Ready to provide robot pose.")
    rospy.spin()

if __name__ == "__main__":
    get_pose_server()
