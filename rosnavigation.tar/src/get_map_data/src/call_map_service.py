#!/usr/bin/env python

import rospy
from nav_msgs.srv import GetMap

def call_map_service():
    # 初始化节点
    rospy.init_node('map_data_client', anonymous=True)

    # 等待/static_map服务可用
    rospy.wait_for_service('/static_map')

    try:
        # 创建服务客户端
        get_map = rospy.ServiceProxy('/static_map', GetMap)

        # 调用服务
        response = get_map()

        # 打印地图的尺寸和分辨率
        print("Map Dimensions: {} x {}".format(response.map.info.width, response.map.info.height))
        print("Map Resolution: {}".format(response.map.info.resolution))

    except rospy.ServiceException as e:
        print("Service call failed: {}".format(e))

if __name__ == '__main__':
    call_map_service()
