#!/usr/bin/env python

import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import Empty

class SendGoalClient:
    def __init__(self):
        rospy.init_node('send_goal_client')
        self.client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
        self.client.wait_for_server()

    def send_goal(self, pose):
        goal = MoveBaseGoal()
        goal.target_pose = pose
        self.client.send_goal(goal)
        self.client.wait_for_result()

def main():
    client = SendGoalClient()

    while not rospy.is_shutdown():
        # Define three different poses (update these with your desired poses)
        pose1 = PoseStamped()
        pose1.header.frame_id = 'map'
        pose1.pose.position.x = 1.0
        pose1.pose.position.y = 2.0
        pose1.pose.orientation.w = 1.0

        pose2 = PoseStamped()
        pose2.header.frame_id = 'map'
        pose2.pose.position.x = 3.0
        pose2.pose.position.y = 2.0
        pose2.pose.orientation.w = 1.0

        pose3 = PoseStamped()
        pose3.header.frame_id = 'map'
        pose3.pose.position.x = 5.0
        pose3.pose.position.y = 2.0
        pose3.pose.orientation.w = 1.0

        # Send goals in a loop
        client.send_goal(pose1)
        rospy.sleep(1.0)

        client.send_goal(pose2)
        rospy.sleep(1.0)

        client.send_goal(pose3)
        rospy.sleep(1.0)

if __name__ == '__main__':
    main()
