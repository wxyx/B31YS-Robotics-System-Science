#!/usr/bin/env python

import rospy
from initialize_particles.srv import GlobalLocalization

def init_particles_client():
    rospy.wait_for_service('/global_localization')
    try:
        global_localization = rospy.ServiceProxy('/global_localization', GlobalLocalization)
        # Call the service to disperse particles
        response = global_localization()
        return response.success
    except rospy.ServiceException as e:
        print(f"Service call failed: {e}")

if __name__ == '__main__':
    rospy.init_node('init_particles_client')
    success = init_particles_client()
    if success:
        print("Particles dispersed successfully!")
    else:
        print("Failed to disperse particles.")
