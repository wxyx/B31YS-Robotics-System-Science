#!/usr/bin/env python

import rospy
from navigation_exam.srv import SendPosition, SendPositionResponse
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
import actionlib
import yaml

class GoalServiceServer:
    def __init__(self):
        rospy.init_node('goal_service_server')
        self.service = rospy.Service('/send_pose_service', SendPosition, self.handle_send_pose_service)

        # Create an action client for move_base
        self.client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
        self.client.wait_for_server()

        # Load points from YAML file
        with open('/home/user/catkin_ws/src/navigation_exam/params/points.yaml', 'r') as file:
            self.points = yaml.safe_load(file)

    def handle_send_pose_service(self, req):
        label = req.label

        if label not in self.points:
            return SendPositionResponse("Label not found")

        goal = MoveBaseGoal()
        point_data = self.points[label]

        goal.target_pose.header.frame_id = 'map'
        goal.target_pose.pose.position.x = point_data['position']['x']
        goal.target_pose.pose.position.y = point_data['position']['y']
        goal.target_pose.pose.position.z = point_data['position']['z']
        goal.target_pose.pose.orientation.x = point_data['orientation']['x']
        goal.target_pose.pose.orientation.y = point_data['orientation']['y']
        goal.target_pose.pose.orientation.z = point_data['orientation']['z']
        goal.target_pose.pose.orientation.w = point_data['orientation']['w']

        # Send the goal to move_base Action Server
        self.client.send_goal(goal)

        # Wait for the result with a timeout (adjust timeout as needed)
        success = self.client.wait_for_result(rospy.Duration(60.0))

        if success:
            return SendPositionResponse("OK")
        else:
            return SendPositionResponse("Failed to reach the goal")

if __name__ == '__main__':
    try:
        goal_service_server = GoalServiceServer()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
