#!/usr/bin/env python

import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from std_msgs.msg import String
import yaml

def send_goals():
    rospy.init_node('send_goals', anonymous=True)

    # Load points from YAML file
    with open('/home/user/catkin_ws/src/navigation_exam/params/points.yaml', 'r') as file:
        points = yaml.safe_load(file)

    # Create an action client for move_base
    client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
    client.wait_for_server()

    # Create goals from loaded points
    goals = [MoveBaseGoal() for _ in range(len(points))]
    for i, (point_name, point_data) in enumerate(points.items()):
        goals[i].target_pose.header.frame_id = 'map'
        goals[i].target_pose.pose.position.x = point_data['position']['x']
        goals[i].target_pose.pose.position.y = point_data['position']['y']
        goals[i].target_pose.pose.position.z = point_data['position']['z']
        goals[i].target_pose.pose.orientation.x = point_data['orientation']['x']
        goals[i].target_pose.pose.orientation.y = point_data['orientation']['y']
        goals[i].target_pose.pose.orientation.z = point_data['orientation']['z']
        goals[i].target_pose.pose.orientation.w = point_data['orientation']['w']

    while not rospy.is_shutdown():
        # Send goals in a loop
        for goal in goals:
            client.send_goal(goal)
            client.wait_for_result()

if __name__ == '__main__':
    try:
        send_goals()
    except rospy.ROSInterruptException:
        pass
